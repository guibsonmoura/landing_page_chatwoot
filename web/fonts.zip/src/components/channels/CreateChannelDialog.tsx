'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { MessageSquare, Code, Link2, Loader2, Check, Plus, Bot as BotIcon, AlertCircle, AlertTriangle } from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import { usePlanStore } from '@/stores/planStore';
import { createChannel, updateChannel, getChannels } from '@/lib/actions/channel.actions';
import { getAgents } from '@/lib/actions/agent.actions';
import { type Channel } from '@/types/channel';
import { cn } from '@/lib/utils';

// Schema de validação para o formulário do lado do cliente
const formSchema = z.object({
  platform: z.string().min(1, 'Selecione uma plataforma.'),
  account: z.string().min(1, 'O nome da conta é obrigatório.'),
  config: z.string().min(2, 'A configuração JSON é obrigatória.').refine((val) => {
    try {
      JSON.parse(val);
      return true;
    } catch (e) {
      return false;
    }
  }, { message: 'A configuração deve ser um JSON válido.' }),
  agent_id: z.string().optional(),
}).superRefine((data, ctx) => {
  // Validações específicas para cada plataforma
  if (data.platform === 'whatsapp' || data.platform === 'whatsapp_evolution_api') {
    // Validação para WhatsApp: formato brasileiro 55 + DDD (2 dígitos) + número (8 ou 9 dígitos)
    const phoneRegex = /^55\d{2}\d{8,9}$/;
    if (!phoneRegex.test(data.account)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'O telefone deve estar no formato: 55 + DDD + número (ex: 5511991234567)',
        path: ['account'],
      });
    }
  } else if (data.platform === 'instagram') {
    // Validação para Instagram: deve começar com @ e ter pelo menos 2 caracteres após o @
    const instagramRegex = /^@[a-zA-Z0-9_.]{2,}$/;
    if (!instagramRegex.test(data.account)) {
      if (!data.account.startsWith('@')) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'O perfil do Instagram deve começar com @ (ex: @meu_perfil)',
          path: ['account'],
        });
      } else {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Nome de usuário inválido. Use apenas letras, números, _ e . (ex: @meu_perfil)',
          path: ['account'],
        });
      }
    }
  } else if (data.platform === 'webchat') {
    // Validação mínima para WebChat: pelo menos 3 caracteres
    if (data.account.length < 3) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'O nome do chat deve ter pelo menos 3 caracteres',
        path: ['account'],
      });
    }
  }
});

type Agent = {
  id: string;
  agent_name: string;
};

interface CreateChannelDialogProps {
  channelToEdit?: Channel | null;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateChannelDialog({ 
  isOpen, 
  onOpenChange, 
  channelToEdit 
}: CreateChannelDialogProps) {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [channelCount, setChannelCount] = useState<number>(0);
  const [isLimitReached, setIsLimitReached] = useState<boolean>(false);

  const planFeatures = usePlanStore((state: any) => state.planFeatures);
  const allowedChannels = planFeatures?.allowed_channels || [];
  const maxChannels = planFeatures?.max_channel || 0;
  const isEditMode = !!channelToEdit;

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      platform: '',
      account: '',
      config: JSON.stringify({ webhook_url: '' }, null, 2),
      agent_id: '',
    },
  });

  // Busca agentes, canais e reseta o formulário quando o diálogo abre
  useEffect(() => {
    if (isOpen) {
      const fetchData = async () => {
        // Busca agentes
        const agentsResult = await getAgents();
        if (agentsResult.data) setAgents(agentsResult.data);
        
        // Busca canais para verificar o limite
        const channelsResult = await getChannels();
        if (channelsResult.data) {
          const currentCount = channelsResult.data.length;
          setChannelCount(currentCount);
          setIsLimitReached(currentCount >= maxChannels);
        }
      };
      fetchData();

      if (isEditMode && channelToEdit) {
        form.reset({
          platform: channelToEdit.platform,
          account: channelToEdit.account,
          config: JSON.stringify(channelToEdit.config, null, 2),
          agent_id: channelToEdit.agent_id || '_none_',
        });
      } else {
        form.reset({
          platform: '',
          account: '',
          config: JSON.stringify({ webhook_url: '' }, null, 2),
          agent_id: '',
        });
      }
    }
  }, [isOpen, isEditMode, channelToEdit, form]);

  async function onSubmit(formValues: z.infer<typeof formSchema>) {
    const values = { ...formValues };
    if (values.agent_id === '_none_') {
      values.agent_id = '';
    }

    setIsSubmitting(true);
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => {
      if (value) formData.append(key, value as string);
    });

    // Adiciona o ID no modo de edição
    if (isEditMode && channelToEdit) {
      formData.append('id', channelToEdit.id);
    }

    const result = isEditMode
      ? await updateChannel(formData)
      : await createChannel(formData);

    setIsSubmitting(false);

    if (result.error) {
      toast.error(`Erro ao ${isEditMode ? 'atualizar' : 'criar'} canal`, { 
        description: result.error 
      });
    } else {
      toast.success(`Canal ${isEditMode ? 'atualizado' : 'criado'} com sucesso!`);
      router.refresh(); // Força a atualização dos dados na página
      onOpenChange(false);
    }
  }

  // Função para determinar o ícone da plataforma
  const getPlatformIcon = (platform: string) => {
    switch (platform?.toLowerCase()) {
      case 'whatsapp':
        return (
          <div className="h-4 w-4 text-green-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
              <path d="M12 0C5.373 0 0 5.373 0 12c0 6.628 5.373 12 12 12 6.628 0 12-5.373 12-12 0-6.628-5.373-12-12-12zm.029 18.88a7.947 7.947 0 0 1-3.77-.97l-4.179 1.096 1.115-4.08a7.952 7.952 0 0 1-1.055-3.965A7.96 7.96 0 0 1 12.03 4c4.4 0 7.97 3.58 7.97 7.98 0 4.399-3.57 7.978-7.97 7.978z"/>
            </svg>
          </div>
        );
      case 'telegram':
        return (
          <div className="h-4 w-4 text-blue-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.87 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.834.941z"/>
            </svg>
          </div>
        );
      case 'instagram':
        return (
          <div className="h-4 w-4 text-pink-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
          </div>
        );
      case 'webchat':
        return (
          <div className="h-4 w-4 text-purple-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 1c-6.338 0-12 4.226-12 10.007 0 2.05.739 4.063 2.047 5.625l-1.993 6.368 6.946-3c1.705.439 3.334.641 4.864.641 7.174 0 12.136-4.439 12.136-9.634 0-5.812-5.701-10.007-12-10.007zm0 1c6.065 0 11 4.041 11 9.007 0 4.922-4.787 8.634-11.136 8.634-1.881 0-3.401-.299-4.946-.695l-5.258 2.271 1.505-4.808c-1.308-1.564-2.165-3.128-2.165-5.402 0-4.966 4.935-9.007 11-9.007zm-5 7.5c.828 0 1.5.672 1.5 1.5s-.672 1.5-1.5 1.5-1.5-.672-1.5-1.5.672-1.5 1.5-1.5zm5 0c.828 0 1.5.672 1.5 1.5s-.672 1.5-1.5 1.5-1.5-.672-1.5-1.5.672-1.5 1.5-1.5zm5 0c.828 0 1.5.672 1.5 1.5s-.672 1.5-1.5 1.5-1.5-.672-1.5-1.5.672-1.5 1.5-1.5z"/>
            </svg>
          </div>
        );
      default:
        return <MessageSquare className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[900px] p-0 overflow-hidden max-h-[85vh] flex flex-col">
        <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
          {/* Sidebar with illustration */}
          <div className="hidden md:flex md:w-1/4 bg-gradient-to-br from-indigo-500 to-purple-600 p-6 flex-col justify-between text-white">
            <div className="space-y-4">
              <div className="h-12 w-12 rounded-lg bg-white/20 flex items-center justify-center">
                <MessageSquare className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">
                Crie um novo canal
              </h3>
              <p className="text-sm text-white/80">
                Conecte seu agente de IA a diferentes plataformas de mensagens para interagir com seus clientes.
              </p>
            </div>
            <div className="mt-auto">
              <div className="flex flex-wrap gap-2 mt-4">
                <div className="px-2 py-1 bg-white/20 rounded-md text-xs flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                  </svg>
                  WhatsApp
                </div>
                <div className="px-2 py-1 bg-white/20 rounded-md text-xs flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.87 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.834.941z"/>
                  </svg>
                  Telegram
                </div>
                <div className="px-2 py-1 bg-white/20 rounded-md text-xs flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                  Instagram
                </div>
                <div className="px-2 py-1 bg-white/20 rounded-md text-xs flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 1c-6.338 0-12 4.226-12 10.007 0 2.05.739 4.063 2.047 5.625l-1.993 6.368 6.946-3c1.705.439 3.334.641 4.864.641 7.174 0 12.136-4.439 12.136-9.634 0-5.812-5.701-10.007-12-10.007zm0 1c6.065 0 11 4.041 11 9.007 0 4.922-4.787 8.634-11.136 8.634-1.881 0-3.401-.299-4.946-.695l-5.258 2.271 1.505-4.808c-1.308-1.564-2.165-3.128-2.165-5.402 0-4.966 4.935-9.007 11-9.007zm-5 7.5c.828 0 1.5.672 1.5 1.5s-.672 1.5-1.5 1.5-1.5-.672-1.5-1.5.672-1.5 1.5-1.5zm5 0c.828 0 1.5.672 1.5 1.5s-.672 1.5-1.5 1.5-1.5-.672-1.5-1.5.672-1.5 1.5-1.5zm5 0c.828 0 1.5.672 1.5 1.5s-.672 1.5-1.5 1.5-1.5-.672-1.5-1.5.672-1.5 1.5-1.5z"/>
                  </svg>
                  WebChat
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="flex flex-col md:w-3/4 h-full">
            <div className="p-6 space-y-6 overflow-y-auto flex-1 max-h-[70vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <MessageSquare className="h-5 w-5 text-indigo-500" />
                {isEditMode ? 'Editar Canal' : 'Criar Novo Canal'}
              </DialogTitle>
              <DialogDescription>
                Conecte seu agente de IA a diferentes plataformas de mensagens para interagir com seus clientes.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                {!isEditMode && isLimitReached && (
                  <div className="mb-4 p-4 border border-red-300 bg-red-50 dark:bg-red-900/20 dark:border-red-800 rounded-lg">
                    <div className="flex items-start">
                      <div className="mr-3 mt-0.5">
                        <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
                      </div>
                      <div>
                        <h5 className="font-medium text-red-800 dark:text-red-300">Limite de canais atingido</h5>
                        <p className="mt-1 text-sm text-red-700 dark:text-red-300">
                          Você já atingiu o limite de {maxChannels} canais do seu plano.
                          Para criar mais canais, faça um upgrade do seu plano.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                <FormField
                  control={form.control}
                  name="platform"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-slate-500" />
                        Plataforma
                        {isEditMode && (
                          <span className="text-xs text-amber-500 font-normal ml-2">
                            (não editável após criação)
                          </span>
                        )}
                      </FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        value={field.value}
                        defaultValue={field.value}
                        disabled={isEditMode} // Desabilita no modo de edição
                      >
                        <FormControl>
                          <SelectTrigger className="w-full border-slate-200 dark:border-slate-700 focus-visible:ring-indigo-500">
                            <SelectValue placeholder="Selecione uma plataforma..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {allowedChannels.filter(Boolean).map((channel: string) => (
                            <SelectItem key={channel} value={channel}>
                              <div className="flex items-center gap-2">
                                {getPlatformIcon(channel)}
                                <span>{channel}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription className="text-xs text-slate-500">
                        Selecione a plataforma de mensagens que deseja conectar.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="account"
                  render={({ field }) => {
                    // Obter o valor atual da plataforma
                    const platform = form.watch('platform');
                    
                    // Definir placeholder, label e descrição baseados na plataforma selecionada
                    let placeholder = "Ex: Meu Bot";
                    let description = "Um nome descritivo para identificar este canal.";
                    let labelText = "Nome da Conta / Identificador";
                    let icon = <MessageSquare className="h-4 w-4 text-slate-500" />;
                    
                    if (platform === 'whatsapp' || platform === 'whatsapp_evolution_api') {
                      placeholder = "Ex: 5511991234567";
                      description = "Formato: 55 + DDD (2 dígitos) + número (8 ou 9 dígitos)";
                      labelText = "Telefone";
                      icon = (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-green-600">
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                      );
                    } else if (platform === 'instagram') {
                      placeholder = "@meu_perfil";
                      description = "Nome do perfil do Instagram começando com @.";
                      labelText = "Instagram";
                      icon = (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-pink-600">
                          <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                        </svg>
                      );
                    } else if (platform === 'webchat') {
                      placeholder = "Ex: Suporte Site";
                      description = "Nome descritivo para o canal de chat do site.";
                      labelText = "Nome do Chat";
                      icon = (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-blue-600">
                          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                      );
                    }
                    
                    return (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          {icon}
                          {labelText}
                          {isEditMode && (
                            <span className="text-xs text-amber-500 font-normal ml-2">
                              (não editável após criação)
                            </span>
                          )}
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input 
                              placeholder={placeholder} 
                              className="w-full border-slate-200 dark:border-slate-700 focus-visible:ring-indigo-500"
                              readOnly={isEditMode} // Torna o campo somente leitura em modo de edição
                              {...field} 
                            />
                            {platform && !isEditMode && (
                              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-slate-400">
                                {platform === 'whatsapp' || platform === 'whatsapp_evolution_api' ? 
                                  <span className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                                    55+DDD+número
                                  </span> : 
                                platform === 'instagram' ? 
                                  <span className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                                    @username
                                  </span> : 
                                  null
                                }
                              </div>
                            )}
                          </div>
                        </FormControl>
                        <FormDescription className="text-xs text-slate-500 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          {description}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />
                <FormField
                  control={form.control}
                  name="config"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Code className="h-4 w-4 text-slate-500" />
                        Configuração (JSON)
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder='{\n  "webhook_url": "https://seu-servico.com/webhook"\n}'
                          className="w-full min-h-[100px] font-mono border-slate-200 dark:border-slate-700 focus-visible:ring-indigo-500 bg-slate-50 dark:bg-slate-900"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription className="text-xs text-slate-500 flex items-center gap-1">
                        <Link2 className="h-3 w-3" />
                        Configurações específicas para conexão com a plataforma.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="agent_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <BotIcon className="h-4 w-4 text-slate-500" />
                        Associar Agente (Opcional)
                      </FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        value={field.value} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full border-slate-200 dark:border-slate-700 focus-visible:ring-indigo-500">
                            <SelectValue placeholder="Selecione um agente..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="_none_">Nenhum</SelectItem>
                          {agents.map((agent) => (
                            <SelectItem key={agent.id} value={agent.id}>
                              {agent.agent_name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription className="text-xs text-slate-500">
                        Escolha qual agente responderá neste canal.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </Form>
            </div>
            <div className="p-6 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 mt-auto">
              <div className="flex gap-3 justify-end">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => onOpenChange(false)}
                  className="border-slate-200 dark:border-slate-700"
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  onClick={form.handleSubmit(onSubmit)}
                  className="px-6 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 transition-all shadow-md hover:shadow-lg hover:translate-y-[-1px] active:translate-y-[1px]"
                  disabled={isSubmitting || (!isEditMode && isLimitReached)}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {isEditMode ? 'Salvando' : 'Processando'}
                    </>
                  ) : (
                    <>
                      {isEditMode ? (
                        <Check className="mr-2 h-4 w-4" />
                      ) : (
                        <Plus className="mr-2 h-4 w-4" />
                      )}
                      {isEditMode ? 'Salvar Alterações' : 'Criar Canal'}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
