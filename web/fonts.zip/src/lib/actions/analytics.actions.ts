'use server';

import { createClient } from '@/lib/supabase/server';
import { cookies } from 'next/headers';
import { AnalyticsDataPoint, DateRange, PeriodFilter, getDateRange } from '@/lib/utils/analytics';

// Interfaces para os totalizadores
export interface TotalizadorData {
  total: number;
  error?: string;
}

// Interface para dados do heatmap
export interface HeatmapDataPoint {
  date: string; // YYYY-MM-DD
  count: number;
  level: number; // 0-4 (intensidade)
}

export interface HeatmapData {
  data: HeatmapDataPoint[];
  maxCount: number;
  totalDays: number;
  error?: string;
}

// Buscar dados de clientes cadastrados por período
export async function getCustomersAnalytics(
  period: PeriodFilter = '7d',
  customStart?: Date,
  customEnd?: Date
) {
  const cookieStore = await cookies();
  const supabase = await createClient();

  try {
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Calcular range de datas
    const { startDate, endDate } = getDateRange(period, customStart, customEnd);
    
    console.log('🔍 [CUSTOMERS ANALYTICS] Debug Info:');
    console.log('  - Period:', period);
    console.log('  - Start Date:', startDate.toISOString());
    console.log('  - End Date:', endDate.toISOString());
    console.log('  - Tenant ID:', tenant.id);
    console.log('  - Custom Start:', customStart);
    console.log('  - Custom End:', customEnd);

    // Query otimizada para buscar clientes por dia
    console.log('🔍 [CUSTOMERS QUERY] SQL Details:');
    console.log('  - Table: customers');
    console.log('  - Tenant ID filter:', tenant.id);
    console.log('  - Start date filter (gte):', startDate.toISOString());
    console.log('  - End date filter (lte):', endDate.toISOString());
    console.log('  - ⚠️  NOTE: RLS policy using get_current_tenant_id() returns null!');
    console.log('  - 💡 SOLUTION: Update customers RLS policy to match tenant_agents policy');
    
    const { data: customersData, error: customersError } = await supabase
      .from('customers')
      .select('created_at')
      .eq('tenant_id', tenant.id)
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString())
      .order('created_at', { ascending: true });
    
    console.log('📊 [CUSTOMERS QUERY] Results:');
    console.log('  - Query Error:', customersError);
    console.log('  - Records Found:', customersData?.length || 0);
    console.log('  - Sample Data:', customersData?.slice(0, 3));
    
    console.log('⚠️  [RLS ISSUE] get_current_tenant_id() returns null - customers table RLS policy needs update!');
    console.log('💡 [SOLUTION] Update customers RLS policy to match tenant_agents policy that works!');
    console.log('🔧 [POLICY FIX] Change from: (tenant_id = get_current_tenant_id())');
    console.log('🔧 [POLICY FIX] Change to: (tenant_id IN (SELECT tenants.id FROM tenants WHERE tenants.user_id = auth.uid()))');
    
    // Since RLS is blocking, return empty data with clear message
    console.log('🚨 [BLOCKED] RLS policy prevents data access - returning empty results until policy is fixed');

    if (customersError) {
      console.error('❌ [CUSTOMERS ERROR]:', customersError);
      throw new Error(`Erro ao buscar clientes: ${customersError.message}`);
    }

    // Agrupar por dia
    const dataMap = new Map<string, number>();
    
    // Inicializar todos os dias do período com 0
    const currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      const dateKey = currentDate.toISOString().split('T')[0];
      dataMap.set(dateKey, 0);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Contar clientes por dia
    customersData?.forEach(customer => {
      const dateKey = customer.created_at.split('T')[0];
      const currentCount = dataMap.get(dateKey) || 0;
      dataMap.set(dateKey, currentCount + 1);
    });

    // Converter para array ordenado
    const analyticsData: AnalyticsDataPoint[] = Array.from(dataMap.entries())
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => a.date.localeCompare(b.date));

    // Calcular total e comparação com período anterior
    const totalCustomers = customersData?.length || 0;
    
    console.log('📈 [CUSTOMERS PROCESSING] Analytics Data:');
    console.log('  - Total Customers:', totalCustomers);
    console.log('  - Analytics Data Points:', analyticsData.length);
    console.log('  - Sample Analytics:', analyticsData.slice(0, 3));
    
    // Buscar dados do período anterior para comparação
    const previousStartDate = new Date(startDate);
    const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    previousStartDate.setDate(startDate.getDate() - daysDiff);
    
    const { data: previousData } = await supabase
      .from('customers')
      .select('id')
      .eq('tenant_id', tenant.id)
      .gte('created_at', previousStartDate.toISOString())
      .lt('created_at', startDate.toISOString());

    const previousTotal = previousData?.length || 0;
    const percentageChange = previousTotal > 0 
      ? Math.round(((totalCustomers - previousTotal) / previousTotal) * 100)
      : totalCustomers > 0 ? 100 : 0;

    const result = {
      data: analyticsData,
      total: totalCustomers,
      percentageChange,
      period: { startDate, endDate }
    };
    
    console.log('✅ [CUSTOMERS FINAL] Result Summary:');
    console.log('  - Total:', result.total);
    console.log('  - Percentage Change:', result.percentageChange + '%');
    console.log('  - Data Points:', result.data.length);
    
    return result;

  } catch (error: any) {
    console.error('Erro ao buscar analytics de clientes:', error);
    return {
      error: error.message,
      data: [],
      total: 0,
      percentageChange: 0
    };
  }
}

// Buscar dados de atendimentos (sessões únicas) por período
export async function getChatAnalytics(
  period: PeriodFilter = '7d',
  customStart?: Date,
  customEnd?: Date
) {
  const cookieStore = await cookies();
  const supabase = await createClient();

  try {
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Calcular range de datas
    const { startDate, endDate } = getDateRange(period, customStart, customEnd);
    
    console.log('🔍 [CHAT ANALYTICS] Debug Info:');
    console.log('  - Period:', period);
    console.log('  - Start Date:', startDate.toISOString());
    console.log('  - End Date:', endDate.toISOString());
    console.log('  - Tenant ID:', tenant.id);
    console.log('  - Custom Start:', customStart);
    console.log('  - Custom End:', customEnd);

    // Query para buscar sessões únicas por dia
    const { data: chatData, error: chatError } = await supabase
      .from('chat_histories')
      .select('session_id, created_at')
      .eq('tenant_id', tenant.id)
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString())
      .order('created_at', { ascending: true });
    
    console.log('💬 [CHAT QUERY] Results:');
    console.log('  - Query Error:', chatError);
    console.log('  - Records Found:', chatData?.length || 0);
    console.log('  - Sample Data:', chatData?.slice(0, 3));

    if (chatError) throw new Error(`Erro ao buscar histórico de chat: ${chatError.message}`);

    // Agrupar sessões únicas por dia
    const sessionsByDay = new Map<string, Set<string>>();
    
    // Inicializar todos os dias do período
    const currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      const dateKey = currentDate.toISOString().split('T')[0];
      sessionsByDay.set(dateKey, new Set());
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Contar sessões únicas por dia
    chatData?.forEach(chat => {
      const dateKey = chat.created_at.split('T')[0];
      const sessionsSet = sessionsByDay.get(dateKey) || new Set();
      sessionsSet.add(chat.session_id);
      sessionsByDay.set(dateKey, sessionsSet);
    });

    // Converter para array de analytics
    const analyticsData: AnalyticsDataPoint[] = Array.from(sessionsByDay.entries())
      .map(([date, sessions]) => ({ date, count: sessions.size }))
      .sort((a, b) => a.date.localeCompare(b.date));

    // Calcular total de atendimentos únicos
    const uniqueSessions = new Set(chatData?.map(chat => chat.session_id) || []);
    const totalSessions = uniqueSessions.size;
    
    console.log('💬 [CHAT PROCESSING] Analytics Data:');
    console.log('  - Total Sessions:', totalSessions);
    console.log('  - Unique Sessions:', uniqueSessions.size);
    console.log('  - Analytics Data Points:', analyticsData.length);
    console.log('  - Sample Analytics:', analyticsData.slice(0, 3));

    // Buscar dados do período anterior para comparação
    const previousStartDate = new Date(startDate);
    const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    previousStartDate.setDate(startDate.getDate() - daysDiff);
    
    const { data: previousData } = await supabase
      .from('chat_histories')
      .select('session_id')
      .eq('tenant_id', tenant.id)
      .gte('created_at', previousStartDate.toISOString())
      .lt('created_at', startDate.toISOString());

    const previousUniqueSessions = new Set(previousData?.map(chat => chat.session_id) || []);
    const previousTotal = previousUniqueSessions.size;
    const percentageChange = previousTotal > 0 
      ? Math.round(((totalSessions - previousTotal) / previousTotal) * 100)
      : totalSessions > 0 ? 100 : 0;

    const result = {
      data: analyticsData,
      total: totalSessions,
      percentageChange,
      period: { startDate, endDate }
    };
    
    console.log('✅ [CHAT FINAL] Result Summary:');
    console.log('  - Total:', result.total);
    console.log('  - Percentage Change:', result.percentageChange + '%');
    console.log('  - Data Points:', result.data.length);
    
    return result;

  } catch (error: any) {
    console.error('Erro ao buscar analytics de chat:', error);
    return {
      error: error.message,
      data: [],
      total: 0,
      percentageChange: 0
    };
  }
}

// ===== TOTALIZADORES =====

// 1. Total de Clientes
export async function getTotalCustomers(): Promise<TotalizadorData> {
  try {
    const supabase = await createClient();
    
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Contar total de clientes
    const { count, error } = await supabase
      .from('customers')
      .select('*', { count: 'exact', head: true })
      .eq('tenant_id', tenant.id);

    if (error) throw new Error(`Erro ao buscar clientes: ${error.message}`);

    console.log('👥 [TOTALIZADOR] Total Clientes:', count || 0);
    return { total: count || 0 };

  } catch (error: any) {
    console.error('Erro ao buscar total de clientes:', error);
    return { total: 0, error: error.message };
  }
}

// 2. Total de Atendimentos (sessões únicas)
export async function getTotalAtendimentos(): Promise<TotalizadorData> {
  try {
    const supabase = await createClient();
    
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Buscar todas as sessões únicas
    const { data: sessions, error } = await supabase
      .from('chat_histories')
      .select('session_id')
      .eq('tenant_id', tenant.id);

    if (error) throw new Error(`Erro ao buscar atendimentos: ${error.message}`);

    // Contar sessões únicas
    const uniqueSessions = new Set(sessions?.map(s => s.session_id) || []);
    const total = uniqueSessions.size;

    console.log('💬 [TOTALIZADOR] Total Atendimentos:', total);
    return { total };

  } catch (error: any) {
    console.error('Erro ao buscar total de atendimentos:', error);
    return { total: 0, error: error.message };
  }
}

// 3. Total de Mensagens Enviadas (AI)
export async function getTotalMensagensEnviadas(): Promise<TotalizadorData> {
  try {
    const supabase = await createClient();
    
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Contar mensagens da IA (type = 'ai')
    const { count, error } = await supabase
      .from('chat_histories')
      .select('*', { count: 'exact', head: true })
      .eq('tenant_id', tenant.id)
      .contains('message', { type: 'ai' });

    if (error) throw new Error(`Erro ao buscar mensagens enviadas: ${error.message}`);

    console.log('🤖 [TOTALIZADOR] Total Mensagens Enviadas (AI):', count || 0);
    return { total: count || 0 };

  } catch (error: any) {
    console.error('Erro ao buscar total de mensagens enviadas:', error);
    return { total: 0, error: error.message };
  }
}

// 4. Total de Mensagens Recebidas (Human)
export async function getTotalMensagensRecebidas(): Promise<TotalizadorData> {
  try {
    const supabase = await createClient();
    
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Contar mensagens do usuário (type = 'human')
    const { count, error } = await supabase
      .from('chat_histories')
      .select('*', { count: 'exact', head: true })
      .eq('tenant_id', tenant.id)
      .contains('message', { type: 'human' });

    if (error) throw new Error(`Erro ao buscar mensagens recebidas: ${error.message}`);

    console.log('👤 [TOTALIZADOR] Total Mensagens Recebidas (Human):', count || 0);
    return { total: count || 0 };

  } catch (error: any) {
    console.error('Erro ao buscar total de mensagens recebidas:', error);
    return { total: 0, error: error.message };
  }
}

// ===== HEATMAP =====

// Buscar dados para heatmap de conversas
export async function getConversationHeatmap(days: number = 30): Promise<HeatmapData> {
  try {
    const supabase = await createClient();
    
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    // Calcular data de início (X dias atrás)
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - days);
    
    console.log('🔥 [HEATMAP] Buscando dados:');
    console.log('  - Tenant ID:', tenant.id);
    console.log('  - Start Date:', startDate.toISOString());
    console.log('  - End Date:', endDate.toISOString());
    console.log('  - Days:', days);

    // Buscar todas as conversas no período
    const { data: conversations, error } = await supabase
      .from('chat_histories')
      .select('created_at, session_id')
      .eq('tenant_id', tenant.id)
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString())
      .order('created_at', { ascending: true });

    if (error) throw new Error(`Erro ao buscar conversas: ${error.message}`);

    console.log('💬 [HEATMAP] Conversas encontradas:', conversations?.length || 0);

    // Agrupar conversas por data e contar sessões únicas
    const conversationsByDate = new Map<string, Set<string>>();
    
    // Inicializar todos os dias do período com 0
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dateKey = d.toISOString().split('T')[0];
      conversationsByDate.set(dateKey, new Set());
    }

    // Processar conversas
    conversations?.forEach(conv => {
      const date = new Date(conv.created_at);
      const dateKey = date.toISOString().split('T')[0];
      
      if (!conversationsByDate.has(dateKey)) {
        conversationsByDate.set(dateKey, new Set());
      }
      
      // Adicionar session_id ao set (para contar sessões únicas por dia)
      conversationsByDate.get(dateKey)!.add(conv.session_id);
    });

    // Converter para array e calcular níveis de intensidade
    const dataPoints: HeatmapDataPoint[] = [];
    let maxCount = 0;

    conversationsByDate.forEach((sessions, date) => {
      const count = sessions.size;
      if (count > maxCount) maxCount = count;
      
      dataPoints.push({
        date,
        count,
        level: 0 // Será calculado depois
      });
    });

    // Calcular níveis de intensidade (0-4)
    const processedData = dataPoints.map(point => ({
      ...point,
      level: maxCount === 0 ? 0 : Math.min(4, Math.floor((point.count / maxCount) * 4))
    }));

    console.log('📊 [HEATMAP] Dados processados:');
    console.log('  - Total Days:', processedData.length);
    console.log('  - Max Count:', maxCount);
    console.log('  - Sample Data:', processedData.slice(0, 5));

    return {
      data: processedData,
      maxCount,
      totalDays: processedData.length,
    };

  } catch (error: any) {
    console.error('Erro ao buscar dados do heatmap:', error);
    return {
      data: [],
      maxCount: 0,
      totalDays: 0,
      error: error.message
    };
  }
}

// Interface para parâmetros do sistema
export interface SystemParams {
  hourlyRateAttendant: number;
  hourlyRateOvertime: number;
  hourlyRateWeekend: number;
  hourlyRateNight: number;
  businessHoursStart: string;
  businessHoursEnd: string;
  nightHoursStart: string;
  nightHoursEnd: string;
  avgConversationDuration: number;
  aiResponseTime: number;
  humanResponseTime: number;
}

// Buscar parâmetros de métricas de valor da nova tabela dedicada
export async function getValueMetricsParams(): Promise<SystemParams> {
  try {
    const supabase = await createClient();
    
    // Buscar parâmetros da tabela value_metrics_config
    const { data: params, error } = await supabase
      .from('value_metrics_config')
      .select('key, value')
      .eq('is_active', true)
      .in('key', [
        'hourly_rate_attendant',
        'hourly_rate_overtime', 
        'hourly_rate_weekend',
        'hourly_rate_night',
        'business_hours_start',
        'business_hours_end',
        'night_hours_start',
        'night_hours_end',
        'avg_conversation_duration',
        'ai_response_time',
        'human_response_time'
      ]);

    if (error) {
      console.warn('Erro ao buscar parâmetros de métricas de valor, usando valores padrão:', error);
    }

    // Converter array para objeto com valores padrão
    const paramMap = new Map(params?.map(p => [p.key, p.value.toString()]) || []);
    
    // Função helper para converter horas decimais para formato HH:MM
    const formatHour = (decimalHour: string, defaultValue: string) => {
      const hour = parseFloat(decimalHour);
      if (isNaN(hour)) return defaultValue;
      const hours = Math.floor(hour);
      const minutes = Math.round((hour - hours) * 60);
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    };
    
    return {
      hourlyRateAttendant: parseFloat(paramMap.get('hourly_rate_attendant') || '25.00'),
      hourlyRateOvertime: parseFloat(paramMap.get('hourly_rate_overtime') || '37.50'),
      hourlyRateWeekend: parseFloat(paramMap.get('hourly_rate_weekend') || '50.00'),
      hourlyRateNight: parseFloat(paramMap.get('hourly_rate_night') || '62.50'),
      businessHoursStart: formatHour(paramMap.get('business_hours_start') || '8.00', '08:00'),
      businessHoursEnd: formatHour(paramMap.get('business_hours_end') || '18.00', '18:00'),
      nightHoursStart: formatHour(paramMap.get('night_hours_start') || '22.00', '22:00'),
      nightHoursEnd: formatHour(paramMap.get('night_hours_end') || '6.00', '06:00'),
      avgConversationDuration: parseInt(paramMap.get('avg_conversation_duration') || '15'),
      aiResponseTime: parseInt(paramMap.get('ai_response_time') || '2'),
      humanResponseTime: parseInt(paramMap.get('human_response_time') || '300')
    };

  } catch (error: any) {
    console.error('Erro ao buscar parâmetros de métricas de valor:', error);
    
    // Retornar valores padrão em caso de erro
    return {
      hourlyRateAttendant: 25.00,
      hourlyRateOvertime: 37.50,
      hourlyRateWeekend: 50.00,
      hourlyRateNight: 62.50,
      businessHoursStart: '08:00',
      businessHoursEnd: '18:00',
      nightHoursStart: '22:00',
      nightHoursEnd: '06:00',
      avgConversationDuration: 15,
      aiResponseTime: 2,
      humanResponseTime: 300
    };
  }
}

// Manter função antiga para compatibilidade (deprecated)
export const getSystemParams = getValueMetricsParams;

// Buscar dados históricos totais para heatmap (desde o início)
export async function getConversationHeatmapTotal(): Promise<HeatmapData> {
  try {
    const supabase = await createClient();
    
    // Obter usuário autenticado
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado.');

    // Buscar tenant
    const { data: tenant, error: tenantError } = await supabase
      .from('tenants')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (tenantError || !tenant) throw new Error('Tenant não encontrado.');

    console.log('🔥 [HEATMAP TOTAL] Buscando dados históricos completos:');
    console.log('  - Tenant ID:', tenant.id);

    // Buscar TODAS as conversas históricas (sem limite de data)
    const { data: conversations, error } = await supabase
      .from('chat_histories')
      .select('created_at, session_id')
      .eq('tenant_id', tenant.id)
      .order('created_at', { ascending: true });

    if (error) throw new Error(`Erro ao buscar conversas: ${error.message}`);

    console.log('💬 [HEATMAP TOTAL] Conversas históricas encontradas:', conversations?.length || 0);

    if (!conversations || conversations.length === 0) {
      return {
        data: [],
        maxCount: 0,
        totalDays: 0,
      };
    }

    // Encontrar primeira e última data
    const firstDate = new Date(conversations[0].created_at);
    const lastDate = new Date(conversations[conversations.length - 1].created_at);
    
    console.log('📅 [HEATMAP TOTAL] Período histórico:');
    console.log('  - Primeira conversa:', firstDate.toISOString());
    console.log('  - Última conversa:', lastDate.toISOString());
    console.log('  - Dias totais:', Math.ceil((lastDate.getTime() - firstDate.getTime()) / (1000 * 60 * 60 * 24)));

    // Agrupar conversas por data e contar sessões únicas
    const conversationsByDate = new Map<string, Set<string>>();
    
    // Processar conversas
    conversations.forEach(conv => {
      const date = new Date(conv.created_at);
      const dateKey = date.toISOString().split('T')[0];
      
      if (!conversationsByDate.has(dateKey)) {
        conversationsByDate.set(dateKey, new Set());
      }
      
      // Adicionar session_id ao set (para contar sessões únicas por dia)
      conversationsByDate.get(dateKey)!.add(conv.session_id);
    });

    // Converter para array e calcular níveis de intensidade
    const dataPoints: HeatmapDataPoint[] = [];
    let maxCount = 0;

    conversationsByDate.forEach((sessions, date) => {
      const count = sessions.size;
      if (count > maxCount) maxCount = count;
      
      dataPoints.push({
        date,
        count,
        level: 0 // Será calculado depois
      });
    });

    // Calcular níveis de intensidade (0-4)
    const processedData = dataPoints.map(point => ({
      ...point,
      level: maxCount === 0 ? 0 : Math.min(4, Math.floor((point.count / maxCount) * 4))
    }));

    console.log('📊 [HEATMAP TOTAL] Dados históricos processados:');
    console.log('  - Total Days:', processedData.length);
    console.log('  - Max Count:', maxCount);
    console.log('  - Total Conversations:', conversations.length);
    console.log('  - Sample Data:', processedData.slice(0, 3));

    return {
      data: processedData,
      maxCount,
      totalDays: processedData.length,
    };

  } catch (error: any) {
    console.error('Erro ao buscar dados históricos do heatmap:', error);
    return {
      data: [],
      maxCount: 0,
      totalDays: 0,
      error: error.message
    };
  }
}
