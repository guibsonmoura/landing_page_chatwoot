'use server';

import { cookies } from 'next/headers';
import { createClient } from '@/lib/supabase/server';
import { Archetype, PersonalityTrait, ConversationFlow } from '@/types/wizard';

// BE-102: Server Actions to fetch templates

/**
 * Fetches agent archetypes from the database.
 * @param niche - Optional filter by niche.
 * @param use_case - Optional filter by use case.
 * @returns A promise that resolves to an array of agent archetypes.
 */
export async function getAgentArchetypes(
  niche?: string,
  use_case?: string
): Promise<Archetype[]> {
  console.log('--- [ACTION] getAgentArchetypes: Executing ---');

  const supabase = await createClient();

  try {
    let query = supabase.from('agent_archetypes').select('*').eq('is_active', true);

    if (niche) {
      console.log(`- Filtering by niche: ${niche}`);
      query = query.eq('niche', niche);
    }
    if (use_case) {
      console.log(`- Filtering by use_case: ${use_case}`);
      query = query.eq('use_case', use_case);
    }

    console.log('- Awaiting Supabase query...');
    const { data, error } = await query;

    if (error) {
      console.error('--- [ACTION] getAgentArchetypes: Supabase Error ---', error.message);
      throw new Error('Could not fetch agent archetypes.');
    }

    console.log(`--- [ACTION] getAgentArchetypes: Supabase Success ---`);
    console.log(`- Found ${data?.length || 0} archetypes.`);
    
    // Log para ver uma amostra dos dados retornados
    if (data && data.length > 0) {
        console.log('- Sample data:', JSON.stringify(data[0], null, 2));
    }

    return data || [];
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('--- [ACTION] getAgentArchetypes: Unexpected Error ---', errorMessage);
    return [];
  }
}

/**
 * Fetches personality traits from the database.
 * @returns A promise that resolves to an array of personality traits.
 */
export async function getPersonalityTraits(): Promise<PersonalityTrait[]> {
  console.log('--- [ACTION] getPersonalityTraits: Executing ---');
  const supabase = await createClient();

  try {
    console.log('- Building Supabase query for personality_traits...');
    const query = supabase
      .from('personality_traits')
      .select('*')
      .eq('is_active', true);

    console.log('- Awaiting Supabase query...');
    const { data, error } = await query;

    if (error) {
      console.error('--- [ACTION] getPersonalityTraits: Supabase Error ---', error.message);
      throw new Error('Could not fetch personality traits.');
    }

    console.log(`--- [ACTION] getPersonalityTraits: Supabase Success ---`);
    console.log(`- Found ${data?.length || 0} traits.`);
    
    if (data && data.length > 0) {
        console.log('- Sample data:', JSON.stringify(data.slice(0, 2), null, 2)); // Log first 2 items
    }

    return data || [];
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('--- [ACTION] getPersonalityTraits: Unexpected Error ---', errorMessage);
    return [];
  }
}

/**
 * Fetches conversation flows from the database.
 * @param niche - Optional filter by niche.
 * @returns A promise that resolves to an array of conversation flows.
 */
export async function getConversationFlows(
  niche?: string
): Promise<ConversationFlow[]> {
  console.log('--- [ACTION] getConversationFlows: Executing ---');
  const supabase = await createClient();

  try {
    console.log('- Building Supabase query for conversation_flows...');
    let query = supabase.from('conversation_flows').select('*').eq('is_active', true);

    if (niche) {
      console.log(`- Filtering by niche: ${niche}`);
      query = query.eq('niche', niche);
    }

    console.log('- Awaiting Supabase query...');
    const { data, error } = await query;

    if (error) {
      console.error('--- [ACTION] getConversationFlows: Supabase Error ---', error.message);
      throw new Error('Could not fetch conversation flows.');
    }

    console.log(`--- [ACTION] getConversationFlows: Supabase Success ---`);
    console.log(`- Found ${data?.length || 0} flows.`);
    
    if (data && data.length > 0) {
        console.log('- Sample data:', JSON.stringify(data.slice(0, 2), null, 2)); // Log first 2 items
    }

    return data || [];
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('--- [ACTION] getConversationFlows: Unexpected Error ---', errorMessage);
    return [];
  }
}
