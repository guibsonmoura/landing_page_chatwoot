import pino from 'pino';

// Defina os níveis de log que você deseja usar
const levels = {
  error: 60,
  warn: 40,
  info: 30,
  debug: 20,
};

const logger = pino({
  level: process.env.LOG_LEVEL || 'info', // Padrão para 'info' se não for especificado
  customLevels: levels,
  useOnlyCustomLevels: true,
  formatters: {
    level: (label) => {
      return { level: label };
    },
  },
  // Em desenvolvimento, usamos 'pino-pretty' para logs legíveis.
  // Em produção, os logs serão em formato JSON para fácil processamento.
  transport: process.env.NODE_ENV !== 'production' ? {
    target: 'pino-pretty',
    options: {
      colorize: true,
      translateTime: 'SYS:dd-mm-yyyy HH:MM:ss',
      ignore: 'pid,hostname',
    },
  } : undefined,
});

export default logger;
