import { createClient } from '@/lib/supabase/server';

import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const cookieStore = await cookies();
  const supabase = await createClient(cookieStore);
  const apiKey = process.env.WHATSAPP_WEBHOOK_API_KEY;
  const apiKeyHeader = request.headers.get('apikey');

  try {
    let tenant_id: string | null = null;
    const body = await request.json();
    console.log('[WHATSAPP_PROXY] Corpo da requisição recebido:', body);

    // Prioriza autenticação por API Key para webhooks externos
    if (apiKeyHeader && apiKeyHeader === apiKey) {
      console.log('[WHATSAPP_PROXY] Autenticação via API Key bem-sucedida.');
      // Para webhooks, o tenant_id deve vir no corpo da requisição
      if (body.tenant_id) {
        tenant_id = body.tenant_id;
        console.log(`[WHATSAPP_PROXY] Tenant ID recebido do webhook: ${tenant_id}`);
      } else {
        console.warn('[WHATSAPP_PROXY] Chamada de webhook autenticada, mas sem tenant_id no corpo.');
        // Dependendo da lógica, pode ser um erro
      }
    } else {
      // Fallback para autenticação de usuário (chamadas do frontend)
      const { data: { user }, error: authError } = await supabase.auth.getUser();

      if (authError || !user) {
        console.error('[WHATSAPP_PROXY] Falha na autenticação de usuário:', authError);
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
      }
      console.log(`[WHATSAPP_PROXY] Usuário autenticado: ${user.id}`);

      const { data: tenantData, error: tenantError } = await supabase
        .from('tenants')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (tenantError || !tenantData) {
        console.error('[WHATSAPP_PROXY] Erro ao buscar tenant para o usuário:', tenantError);
        return NextResponse.json({ error: 'Tenant não encontrado.' }, { status: 500 });
      }
      tenant_id = tenantData.id;
      console.log(`[WHATSAPP_PROXY] Tenant ID obtido do usuário: ${tenant_id}`);
    }

    // Se nenhum método de autenticação funcionou ou tenant_id não foi encontrado
    if (!tenant_id) {
        console.error('[WHATSAPP_PROXY] Não foi possível determinar o tenant_id. Acesso negado.');
        return NextResponse.json({ error: 'Não autorizado: tenant_id ausente.' }, { status: 401 });
    }

    const baseUrl = process.env.WHATSAPP_WEBHOOK_URL;

    // Validação crítica das variáveis de ambiente
    if (!baseUrl || !apiKey) {
      console.error('[WHATSAPP_PROXY] Erro Crítico: As variáveis de ambiente WHATSAPP_WEBHOOK_URL ou WHATSAPP_WEBHOOK_API_KEY não estão definidas no servidor.');
      return NextResponse.json({ error: 'Configuração do servidor incompleta para o serviço de WhatsApp.' }, { status: 500 });
    }

    console.log('[WHATSAPP_PROXY] Variáveis de ambiente do webhook carregadas.');

    const webhookUrl = `${baseUrl}/${body.endpoint}`;
    console.log(`[WHATSAPP_PROXY] Disparando webhook para: ${webhookUrl}`);
    const webhookPayload = { ...body, tenant_id };
    // logger.info({ webhookUrl, webhookPayload }, '[WHATSAPP_PROXY] Disparando webhook.');

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': apiKey,
      },
      body: JSON.stringify(webhookPayload),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('[WHATSAPP_PROXY] Erro ao chamar o webhook:', {
        status: response.status,
        statusText: response.statusText,
        body: errorBody,
      });
      return NextResponse.json({ error: 'Falha ao comunicar com o serviço de WhatsApp.', details: errorBody }, { status: response.status });
    }

    const responseData = await response.json();
    console.log('[WHATSAPP_PROXY] Webhook disparado com sucesso:', responseData);

    return NextResponse.json(responseData);

  } catch (error) {
    console.error('[WHATSAPP_PROXY] Erro inesperado no handler da rota:', error);
    return NextResponse.json({ error: 'Erro interno do servidor.' }, { status: 500 });
  }
}